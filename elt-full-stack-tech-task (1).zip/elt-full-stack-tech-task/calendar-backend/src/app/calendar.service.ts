import { BadRequestException, Injectable } from '@nestjs/common';
import { CalendarEventRepository } from '@fs-tech-test/calendar-domain';

@Injectable()
export class CalendarService {
  constructor(
    private readonly calendarEventRepository: CalendarEventRepository,
  ) {}

  async getEvents(start: string, end: string) {
    if (!start || !end) throw new BadRequestException('No start/end specified');

    return this.calendarEventRepository.findForRange(
      new Date(start),
      new Date(end),
    );
  }

  async addEvent(payload: EventPayload) {
    const events = await this.calendarEventRepository.getConflictingEvents(
      new Date(payload.start),
      new Date(payload.end),
    );

    if (events.length > 0) {
      throw new BadRequestException('Event conflicts with existing events');
    }

    const newEntity = await this.calendarEventRepository.createNewEvent(
      payload.name,
      new Date(payload.start),
      new Date(payload.end),
    );

    return newEntity.id;
  }

  async deleteEvent(id: number) {
    await this.calendarEventRepository.deleteById(id);
  }

  async updateEvent(id: number, payload: Partial<EventPayload>) {
    const events = await this.calendarEventRepository.getConflictingEvents(
      new Date(payload.start),
      new Date(payload.end),
    );

    const filteredEvents = events.filter((event) => event.id !== id);
    if (filteredEvents.length > 0) {
      throw new BadRequestException('Event conflicts with existing events');
    }

    const updateData = {
      ...payload,
      start: new Date(payload.start),
      end: new Date(payload.end),
    };

    await this.calendarEventRepository.updateEvent(id, updateData);
  }
} 