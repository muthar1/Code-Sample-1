interface EventPayload {
  name: string;
  start: string;
  end: string;
}
