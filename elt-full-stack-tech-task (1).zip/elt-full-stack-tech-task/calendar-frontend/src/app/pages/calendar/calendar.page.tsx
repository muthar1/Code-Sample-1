import { CalendarView } from './components/calendar-view/calendar-view';
import { CalendarToolbar } from './components/calendar-toolbar/calendar-toolbar';
import { useCalendar } from './hooks/use-calendar';
import { Toaster } from 'react-hot-toast';

export const CalendarPage = () => {
  const {
    events,
    addEvent,
    onNavigate,
    updateEvent,
  } = useCalendar();

  return (
    <div>
      <Toaster position="top-right" reverseOrder={false} />
      <CalendarToolbar
        addEvent={addEvent}
        updateEvent={updateEvent}
      />
      <CalendarView
        onNavigate={onNavigate}
        events={events}
        updateEvent={updateEvent}
      />
    </div>
  );
};
