import { useState, useEffect } from 'react';
import moment from 'moment';
import { EltEvent } from '../../../../common/types';
import { AxiosError } from 'axios';
import {
  ModalOverlay,
  ModalContent,
  ErrorMessage,
  FormGroup,
  FormRow,
  ModalActions,
  CancelButton,
  SubmitButton
} from './event-modal.styled';

interface EventModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (event: { title: string; start: Date; end: Date }) => Promise<void>;
  initialEvent?: Partial<EltEvent>;
  title?: string;
}

export const EventModal = ({
  isOpen,
  onClose,
  onSubmit,
  initialEvent,
  title = 'Create Event',
}: EventModalProps) => {
  const [eventName, setEventName] = useState('');
  const [startDate, setStartDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endDate, setEndDate] = useState('');
  const [endTime, setEndTime] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (isOpen) {
      // Set default values or use initialEvent if provided
      const now = moment();
      const oneHourLater = moment().add(1, 'hour');

      if (initialEvent?.title) {
        setEventName(initialEvent.title);
      } else {
        setEventName('');
      }

      if (initialEvent?.start) {
        const start = moment(initialEvent.start);
        setStartDate(start.format('YYYY-MM-DD'));
        setStartTime(start.format('HH:mm'));
      } else {
        setStartDate(now.format('YYYY-MM-DD'));
        setStartTime(now.format('HH:mm'));
      }

      if (initialEvent?.end) {
        const end = moment(initialEvent.end);
        setEndDate(end.format('YYYY-MM-DD'));
        setEndTime(end.format('HH:mm'));
      } else {
        setEndDate(oneHourLater.format('YYYY-MM-DD'));
        setEndTime(oneHourLater.format('HH:mm'));
      }

      setError('');
    }
  }, [isOpen, initialEvent]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!eventName.trim()) {
      setError('Event name is required');
      return;
    }

    const startDateTime = moment(`${startDate} ${startTime}`);
    const endDateTime = moment(`${endDate} ${endTime}`);

    if (!startDateTime.isValid() || !endDateTime.isValid()) {
      setError('Invalid date or time');
      return;
    }

    if (endDateTime.isSameOrBefore(startDateTime)) {
      setError('End time must be after start time');
      return;
    }

    try {
      await onSubmit({
        title: eventName,
        start: startDateTime.toDate(),
        end: endDateTime.toDate(),
      });
      onClose();
    } catch (error) {
      const errorMessage =
        (error as AxiosError<{ message: string }>).response?.data?.message ||
        'Failed to save event. Please try again.';
      setError(errorMessage);
    }
  };

  if (!isOpen) return null;

  return (
    <ModalOverlay>
      <ModalContent>
        <h2>{title}</h2>
        {error && <ErrorMessage>{error}</ErrorMessage>}
        <form onSubmit={handleSubmit}>
          <FormGroup>
            <label htmlFor="event-name">Event Name</label>
            <input
              id="event-name"
              type="text"
              value={eventName}
              onChange={(e) => setEventName(e.target.value)}
              placeholder="Enter event name"
              required
            />
          </FormGroup>

          <FormRow>
            <FormGroup>
              <label htmlFor="start-date">Start Date</label>
              <input
                id="start-date"
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                required
              />
            </FormGroup>
            <FormGroup>
              <label htmlFor="start-time">Start Time</label>
              <input
                id="start-time"
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                required
              />
            </FormGroup>
          </FormRow>

          <FormRow>
            <FormGroup>
              <label htmlFor="end-date">End Date</label>
              <input
                id="end-date"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                required
              />
            </FormGroup>
            <FormGroup>
              <label htmlFor="end-time">End Time</label>
              <input
                id="end-time"
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                required
              />
            </FormGroup>
          </FormRow>

          <ModalActions>
            <CancelButton type="button" onClick={onClose}>
              Cancel
            </CancelButton>
            <SubmitButton type="submit">
              Save Event
            </SubmitButton>
          </ModalActions>
        </form>
      </ModalContent>
    </ModalOverlay>
  );
};
