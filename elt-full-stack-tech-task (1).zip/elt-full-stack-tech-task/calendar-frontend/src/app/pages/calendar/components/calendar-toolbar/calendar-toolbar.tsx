import { EltEvent } from '../../../../common/types';
import { useState } from 'react';
import { ToolbarStyle } from './styles/calendar-toolbar-style';
import { EventModal } from '../event-modal/event-modal';
import { useCalendarContext } from '../../../../context/calendar-context';

interface ICalendarToolbarProps {
  addEvent: (event: Omit<EltEvent, 'id'>) => Promise<void>;
  updateEvent: (
    id: number,
    event: Partial<{ start: Date; end: Date; title: string }>,
  ) => Promise<void>;
}

export const CalendarToolbar = ({
  addEvent,
  updateEvent,
}: ICalendarToolbarProps) => {
  const { showIds, setShowIds, selectedEvent } = useCalendarContext();
  const [isEventModalOpen, setIsEventModalOpen] = useState(false);
  const [eventModalAction, setEventModalAction] = useState<'create' | 'edit'>(
    'create',
  );

  const openEventModal = (action: 'create' | 'edit') => {
    setEventModalAction(action);
    setIsEventModalOpen(true);
  };

  const closeEventModal = () => {
    setIsEventModalOpen(false);
  };

  const editEvent = async (event: {
    title: string;
    start: Date;
    end: Date;
  }) => {
    if (!selectedEvent?.id) return;

    updateEvent(selectedEvent.id, event);
  };

  return (
    <div css={ToolbarStyle}>
      <button
        data-testid="add-event-btn"
        onClick={() => openEventModal('create')}
      >
        Add event
      </button>
      <button
        data-testid="edit-event-btn"
        onClick={() => openEventModal('edit')}
        disabled={!selectedEvent}
      >
        Edit event
      </button>
      <label htmlFor="show-ids-checkbox">
        <input
          id="show-ids-checkbox"
          type="checkbox"
          defaultChecked={showIds}
          onClick={(e) => setShowIds(e.currentTarget.checked)}
        ></input>
        Show ids
      </label>

      {/* Create Event Modal */}
      <EventModal
        isOpen={isEventModalOpen}
        onClose={closeEventModal}
        onSubmit={eventModalAction === 'edit' ? editEvent : addEvent}
        initialEvent={eventModalAction === 'edit' ? selectedEvent : undefined}
        title={eventModalAction === 'edit' ? 'Edit Event' : 'Create New Event'}
      />
    </div>
  );
};
