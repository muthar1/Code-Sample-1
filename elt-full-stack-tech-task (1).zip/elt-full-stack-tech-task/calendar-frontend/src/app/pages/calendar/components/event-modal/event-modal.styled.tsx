import styled from '@emotion/styled';
import { keyframes } from '@emotion/react';

const fadeIn = keyframes`
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
`;

const slideUp = keyframes`
  from {
    opacity: 0;
    transform: translateY(20px) scale(0.95);
  }
  to {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
`;

export const ModalOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
  backdrop-filter: blur(3px);
  animation: ${fadeIn} 0.2s ease-out;
`;

export const ModalContent = styled.div`
  background-color: white;
  padding: 28px;
  border-radius: 12px;
  width: 100%;
  max-width: 520px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
  animation: ${slideUp} 0.3s ease-out;
  transform-origin: center bottom;
  overflow: hidden;
  box-sizing: border-box;

  h2 {
    margin-top: 0;
    margin-bottom: 20px;
    color: #2c3e50;
    font-size: 1.5rem;
    font-weight: 600;
    border-bottom: 2px solid #f0f0f0;
    padding-bottom: 12px;
  }

  @media (max-width: 576px) {
    max-width: 90%;
    padding: 20px;
    margin: 0 16px;
  }
`;

export const ErrorMessage = styled.div`
  background-color: #fff2f2;
  color: #e74c3c;
  padding: 12px 16px;
  border-radius: 8px;
  margin-bottom: 20px;
  font-size: 14px;
  border-left: 4px solid #e74c3c;
  display: flex;
  align-items: center;

  &::before {
    content: '⚠️';
    margin-right: 8px;
    font-size: 16px;
  }
`;

export const FormGroup = styled.div`
  margin-bottom: 20px;
  width: 100%;

  label {
    display: flex;
    align-items: center;
    margin-bottom: 8px;
    font-weight: 500;
    color: #4a5568;
    font-size: 0.95rem;
  }

  input {
    width: 100%;
    padding: 12px 16px;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    font-size: 15px;
    transition: all 0.2s ease;
    background-color: #f8fafc;
    box-sizing: border-box;

    &:hover {
      border-color: #cbd5e0;
    }

    &:focus {
      outline: none;
      border-color: #3498db;
      box-shadow: 0 0 0 3px rgba(66, 153, 225, 0.15);
      background-color: #fff;
    }

    &::placeholder {
      color: #a0aec0;
    }
  }
`;

export const FormRow = styled.div`
  display: flex;
  gap: 20px;
  margin-bottom: 15px;

  ${FormGroup} {
    flex: 1;
    min-width: 0;
  }

  @media (max-width: 768px) {
    flex-direction: column;
    gap: 15px;
  }
`;

export const ModalActions = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 16px;
  margin-top: 32px;
  border-top: 1px solid #f0f0f0;
  padding-top: 20px;

  @media (max-width: 576px) {
    flex-direction: column-reverse;

    button {
      width: 100%;
    }
  }
`;

export const Button = styled.button`
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: 600;
  font-size: 15px;
  cursor: pointer;
  transition: all 0.2s ease;
  letter-spacing: 0.3px;

  &:active {
    transform: translateY(1px);
  }
`;

export const CancelButton = styled(Button)`
  background-color: #f7fafc;
  border: 1px solid #e2e8f0;
  color: #4a5568;

  &:hover {
    background-color: #edf2f7;
    color: #2d3748;
  }
`;

export const SubmitButton = styled(Button)`
  background-color: #3498db;
  border: 1px solid #3498db;
  color: white;
  box-shadow: 0 2px 5px rgba(52, 152, 219, 0.2);

  &:hover {
    background-color: #2980b9;
    box-shadow: 0 4px 8px rgba(52, 152, 219, 0.3);
  }

  &:active {
    box-shadow: 0 1px 3px rgba(52, 152, 219, 0.3);
  }
`;
