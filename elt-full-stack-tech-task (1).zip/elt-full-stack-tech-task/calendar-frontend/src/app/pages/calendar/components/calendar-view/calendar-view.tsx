import { Calendar, momentLocalizer, View } from 'react-big-calendar';
import withDragAndDrop, {
  EventInteractionArgs,
} from 'react-big-calendar/lib/addons/dragAndDrop';
import moment from 'moment';
import './styles/calendar.scss';
import { EltEvent } from '../../../../common/types';
import { CalendarFormats } from './formats';
import { useCalendarView } from '../../hooks/use-calendar-view';
import { AxiosError } from 'axios';
import { toast } from 'react-hot-toast';
import { useCalendarContext } from '../../../../context/calendar-context';

const localizer = momentLocalizer(moment);
const DnDCalendar = withDragAndDrop<EltEvent>(Calendar);

interface ICalendarViewProps {
  onNavigate: (date: Date, view: View) => void;
  events: EltEvent[];
  updateEvent: (
    id: number,
    payload: Partial<{ start: Date; end: Date; title: string }>,
  ) => Promise<void>;
}

export const CalendarView = ({
  onNavigate,
  events,
  updateEvent,
}: ICalendarViewProps) => {
  const { showIds, setSelectedEvent } = useCalendarContext();
  const { components } = useCalendarView(showIds);

  const onEventDrop = (params: EventInteractionArgs<EltEvent>) => {
    updateEvent(params.event.id, {
      start: new Date(params.start),
      end: new Date(params.end),
    }).catch((error) => {
      const errorMessage =
        (error as AxiosError<{ message: string }>).response?.data?.message ||
        'Failed to update event';
      toast.error(errorMessage);
    });
  };

  const onEventResize = (params: EventInteractionArgs<EltEvent>) => {
    updateEvent(params.event.id, {
      start: new Date(params.start),
      end: new Date(params.end),
    }).catch((error) => {
      const errorMessage =
        (error as AxiosError<{ message: string }>).response?.data?.message ||
        'Failed to update event';
      toast.error(errorMessage);
    });
  };

  return (
    <DnDCalendar
      components={components}
      defaultDate={moment().toDate()}
      events={events}
      onNavigate={onNavigate}
      defaultView={'week'}
      onSelectEvent={(event) => setSelectedEvent(event as EltEvent)}
      localizer={localizer}
      formats={CalendarFormats}
      onEventDrop={onEventDrop}
      onEventResize={onEventResize}
      resizable
      style={{ height: '80vh' }}
      popup={true}
      dayLayoutAlgorithm={'no-overlap'}
    />
  );
};
