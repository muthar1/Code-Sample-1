import React, { createContext, useContext, useState } from 'react';
import { EltEvent } from '../common/types';

interface CalendarContextType {
  showIds: boolean;
  setShowIds: (show: boolean) => void;
  selectedEvent: Partial<EltEvent> | undefined;
  setSelectedEvent: (event: EltEvent | undefined) => void;
}

const CalendarContext = createContext<CalendarContextType | undefined>(undefined);

export const CalendarProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [showIds, setShowIds] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<Partial<EltEvent>>();

  const value = {
    showIds,
    setShowIds,
    selectedEvent,
    setSelectedEvent,
  };

  return (
    <CalendarContext.Provider value={value}>
      {children}
    </CalendarContext.Provider>
  );
};

export const useCalendarContext = () => {
  const context = useContext(CalendarContext);
  if (context === undefined) {
    throw new Error('useCalendarContext must be used within a CalendarProvider');
  }
  return context;
};
