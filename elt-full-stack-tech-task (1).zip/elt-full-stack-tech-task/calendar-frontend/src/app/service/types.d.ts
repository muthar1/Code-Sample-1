export interface ICalendarEvent {
  id: number;
  name: string;
  start: string;
  end: string;
}
