import { CalendarEventEntity } from './entity/calendar-event.entity';

export const entities = [CalendarEventEntity];
